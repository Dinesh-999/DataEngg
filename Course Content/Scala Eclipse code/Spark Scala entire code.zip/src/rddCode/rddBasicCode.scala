package rddCode

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Row
import org.apache.spark.sql.types._

object rddBasicCode {

  case class schema(id: String, category: String, product: String, mode: String)

  def main(args: Array[String]): Unit = {
    println("===started Zeyo====")
    val conf = new SparkConf().setAppName("first").setMaster("local[*]").set("spark.driver.allowMultipleContexts", "true")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val data = sc.textFile("file:///D:/data/datatxns.txt")
    // ==> Change path according to your local file
    data.foreach(println)

    //    ===========================================

    val usdata = sc.textFile("file:///D:/data/usdata.csv")
    usdata.foreach(println)
    val lendata = usdata.filter(x => x.length > 200)

    println
    println("======len data====")
    lendata.foreach(println)
    println

    println("======flatten data====")
    val flatten = lendata.flatMap(x => x.split(","))
    flatten.foreach(println)

    // ====================================================

    val spark = SparkSession.builder().getOrCreate()
    import spark.implicits._

    val datatxn = sc.textFile("file:///D:/data/datatxns.txt")
    datatxn.foreach(println)
    println
    println
    val mapsplit = datatxn.map(x => x.split(","))
    val schemardd = mapsplit.map(x => schema(x(0), x(1), x(2), x(3)))
    val prodfilter = schemardd.filter(x => x.product.contains("Gymnastics"))
    prodfilter.foreach(println)
    println
    println
    val dataframe = prodfilter.toDF()
    dataframe.show()

    //    ======================================================

    //    val conf = new SparkConf().setAppName("first").setMaster("local[*]").set("spark.driver.allowMultipleContexts","true")
    //    val sc = new SparkContext(conf)
    //    sc.setLogLevel("ERROR")

    //    val spark = SparkSession.builder().getOrCreate()
    //    import spark.implicits._
    //    val data = sc.textFile("/user/<LABUSER>/datatxns.txt")
    //    data.foreach(println)
    //    println

    //    val mapsplit = data.map(x => x.split(","))

    val rowrdd = mapsplit.map(x => Row(x(0), x(1), x(2), x(3)))
    val prodfilter1 = rowrdd.filter(x => x(2).toString().contains("Gymnastics"))
    prodfilter1.foreach(println)

    prodfilter1.foreach(println)
    val simpleSchema = StructType(Array(
      StructField("id", StringType),
      StructField("category", StringType),
      StructField("product", StringType),
      StructField("mode", StringType)))
    val dataframe1 = spark.createDataFrame(prodfilter1, simpleSchema)
    dataframe1.show()

  }
}