package test

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Row
import org.apache.spark.sql.types._

object test1 {
  case class schema(id: String, category: String, product: String, mode: String)
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("first").setMaster("local[*]").set("spark.driver.allowMultipleContexts", "true")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val spark = SparkSession.builder().getOrCreate()
    import spark.implicits._
    val data = sc.textFile("/user/<LABUSER>/datatxns.txt")
    data.foreach(println)
    println
    val mapsplit = data.map(x => x.split(","))
    val rowrdd = mapsplit.map(x => Row(x(0), x(1), x(2), x(3)))
    val prodfilter = rowrdd.filter(x => x(2).toString().contains("Gymnastics"))
    prodfilter.foreach(println)
    val simpleSchema = StructType(Array(
      StructField("id", StringType),
      StructField("category", StringType),
      StructField("product", StringType),
      StructField("mode", StringType)))
    val dataframe1 = spark.createDataFrame(prodfilter, simpleSchema)
    dataframe1.show()
  }
}
