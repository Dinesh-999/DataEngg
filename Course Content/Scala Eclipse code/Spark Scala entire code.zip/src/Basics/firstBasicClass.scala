package Basics

object firstBasicClass {

  def main(args: Array[String]): Unit = {

    println("===spark journey started==")
  }

}